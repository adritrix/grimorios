#!/bin/bash

######################## Bloque datos de BBDD diario########################

dirPaquete="/backups/diario/postgresql/data/"

mkdir -p ${dirPaquete} &>> $archivoLog

remoto="cloud:"

#fecha=`date +%Y_%m_%d_%H_%M`

nombrePaquete="postgresDump_diario"

extension=".tar.gz"

nombrePaqueteCompleto=${dirPaquete}${nombrePaquete}${fecha}${extension}

dirDatos="/tmp/postgresdump/diario/"

mkdir -p ${dirDatos}

sudo -u postgres pg_dump shakespeare  >  ${dirDatos}shakespeare.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t chapter  >  ${dirDatos}shakespeare.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t work  >  ${dirDatos}shakespeare_work.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t wordform  >  ${dirDatos}shakespeare_wordform.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t paragraph  >  ${dirDatos}shakespeare_paragraph.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t character_work  >  ${dirDatos}shakespeare_character_work.sql 2>> $archivoLog

sudo -u postgres pg_dump shakespeare -t character  >  ${dirDatos}shakespeare_character.sql 2>> $archivoLog



tar -vcz -f ${nombrePaqueteCompleto} ${dirDatos} &>> $archivoLog

tamanoTar=`ls -l --block-size=G ${nombrePaqueteCompleto}  | cut -d " " -f 5 | sed s/.$//`
echo $tamanoTar

if [ $tamanoTar -ge 10 ]
then
        echo "el archivo ${nombrePaquete}${fecha}${extension}  es igual a 10GB o mayor de 10GB por lo que sera dividido"
        carpetaSplit=${nombrePaqueteCompleto}_split/
        mkdir -p $carpetaSplit
        split -b 9G ${nombrePaqueteCompleto} ${carpetaSplit}"parte_"
        rclone copy ${dirPaquete} ${remoto}${dirPaquete} &>> $archivoLog
        rm -rf ${nombrePaqueteCompleto}
else

        echo "el archivo ${nombrePaquete}  es menor de 10GB por lo que no sera dividido  "
        rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog
fi

#rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog

#######################################################################################

######################## Bloque conf de BBDD diario########################

dirPaquete="/backups/diario/postgresql/conf/"

mkdir -p ${dirPaquete} &>> $archivoLog

remoto="cloud:"

#fecha=`date +%Y_%m_%d_%H_%M`

nombrePaquete="postgresqlConf"

extension=".tar.gz"

nombrePaqueteCompleto=${dirPaquete}${nombrePaquete}${fecha}${extension}

dirDatos="/tmp/postgresqlConf/"

mkdir -p $dirDatos

cp -r /var/lib/pgsql/data $dirDatos


tar -vcz -f ${nombrePaqueteCompleto} ${dirDatos} &>> $archivoLog

tamanoTar=`ls -l --block-size=G ${nombrePaqueteCompleto}  | cut -d " " -f 5 | sed s/.$//`
echo $tamanoTar

if [ $tamanoTar -ge 10 ]
then
        echo "el archivo ${nombrePaquete}${fecha}${extension}  es igual a 10GB o mayor de 10GB por lo que sera dividido"
        carpetaSplit=${nombrePaqueteCompleto}_split/
        mkdir -p $carpetaSplit
        split -b 9G ${nombrePaqueteCompleto} ${carpetaSplit}"parte_"
        rclone copy ${dirPaquete} ${remoto}${dirPaquete} &>> $archivoLog
        rm -rf ${nombrePaqueteCompleto}
else

        echo "el archivo ${nombrePaquete}  es menor de 10GB por lo que no sera dividido  "
        rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog
fi

#rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog


#####################################################################################
