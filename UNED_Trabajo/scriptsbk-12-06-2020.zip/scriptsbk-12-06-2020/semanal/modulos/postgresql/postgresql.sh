#!/bin/bash

######################## Bloque datos de BBDD diario########################

dirPaquete="/backups/semanal/postgresql/data/"

mkdir -p ${dirPaquete} &>> $archivoLog

remoto="cloud:"

#fecha=`date +%Y_%m_%d_%H_%M`

nombrePaquete="postgresDump_semanal"

extension=".tar.gz"

nombrePaqueteCompleto=${dirPaquete}${nombrePaquete}${fecha}${extension}

dirDatos="/tmp/postgresdump/full/"

mkdir -p ${dirDatos}

sudo -u postgres pg_dumpall >  ${dirDatos}full_databases.sql 2>> $archivoLog

tar -vcz -f ${nombrePaqueteCompleto} ${dirDatos} &>> $archivoLog

tamanoTar=`ls -l --block-size=G ${nombrePaqueteCompleto}  | cut -d " " -f 5 | sed s/.$//`
echo $tamanoTar

if [ $tamanoTar -ge 10 ]
then
        echo "el archivo ${nombrePaquete}${fecha}${extension}  es igual a 10GB o mayor de 10GB por lo que sera dividido"
        carpetaSplit=${nombrePaqueteCompleto}_split/
        mkdir -p $carpetaSplit
        split -b 9G ${nombrePaqueteCompleto} ${carpetaSplit}"parte_"
        rclone copy ${dirPaquete} ${remoto}${dirPaquete} &>> $archivoLog
        rm -rf ${nombrePaqueteCompleto}
else

        echo "el archivo ${nombrePaquete}  es menor de 10GB por lo que no sera dividido  "
        rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog
fi

#rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog


nArchivos=`ls $dirPaquete | wc -l`
while [ $nArchivos -gt 2 ]
do
        cd $dirPaquete
        rm -rf  "$(ls -t | tail -1)"
        nArchivos=`ls $dirPaquete | wc -l`
        rclone sync ${dirPaquete} ${remoto}${dirPaquete}
done

#######################################################################################

######################## Bloque conf de BBDD diario########################

dirPaquete="/backups/semanal/postgresql/conf/"

mkdir -p ${dirPaquete} &>> $archivoLog

remoto="cloud:"

#fecha=`date +%Y_%m_%d_%H_%M`

nombrePaquete="postgresqlConf"

extension=".tar.gz"

nombrePaqueteCompleto=${dirPaquete}${nombrePaquete}${fecha}${extension}

dirDatos="/tmp/postgresqlConf/"

mkdir -p $dirDatos

cp -r /var/lib/pgsql/data $dirDatos


tar -vcz -f ${nombrePaqueteCompleto} ${dirDatos} &>> $archivoLog

tamanoTar=`ls -l --block-size=G ${nombrePaqueteCompleto}  | cut -d " " -f 5 | sed s/.$//`
echo $tamanoTar

if [ $tamanoTar -ge 10 ]
then
        echo "el archivo ${nombrePaquete}${fecha}${extension}  es igual a 10GB o mayor de 10GB por lo que sera dividido"
        carpetaSplit=${nombrePaqueteCompleto}_split/
        mkdir -p $carpetaSplit
        split -b 9G ${nombrePaqueteCompleto} ${carpetaSplit}"parte_"
        rclone copy ${dirPaquete} ${remoto}${dirPaquete} &>> $archivoLog
        rm -rf ${nombrePaqueteCompleto}
else

        echo "el archivo ${nombrePaquete}  es menor de 10GB por lo que no sera dividido  "
        rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog
fi

#rclone copy ${nombrePaqueteCompleto} ${remoto}${dirPaquete} &>> $archivoLog


nArchivos=`ls $dirPaquete | wc -l`
while [ $nArchivos -gt 2 ]
do
        cd $dirPaquete
        rm -rf "$(ls -t | tail -1)"
        nArchivos=`ls $dirPaquete | wc -l`
        rclone sync ${dirPaquete} ${remoto}${dirPaquete}
done

#######################################################################################
